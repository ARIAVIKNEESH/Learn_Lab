import React, { useEffect, useState } from 'react';
import { Bar } from 'react-chartjs-2';
import { CircularProgressbar, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const ParticularStudent = () => {
  const [studentData, setStudentData] = useState(null);
  const [attendanceData, setAttendanceData] = useState([]);
  const [marksData, setMarksData] = useState({
    departmentAverage: 0,
    collegeAverage: 0,
    studentAverage: 0
  });

  const rollno = localStorage.getItem('rollno');

  useEffect(() => {
    const fetchStudentData = async () => {
      try {
        const response = await fetch(`http://localhost:5000/api/managestudents/student/${rollno}`);
        if (!response.ok) {
          throw new Error('Failed to fetch student details');
        }
        const data = await response.json();
        
        setStudentData(data);  
        setAttendanceData(data.attendance); 

        const totalMarks = data.subjects.reduce((sum, subject) => sum + subject.marks, 0);
        const studentAverage = (totalMarks / data.subjects.length) || 0;

        const departmentAverage = 70;
        const collegeAverage = 60;

        setMarksData({ studentAverage, departmentAverage, collegeAverage });
      } catch (error) {
        console.error('Error fetching student details:', error);
      }
    };
    
    if (rollno) {
      fetchStudentData();
    }
  }, [rollno]);

  const barChartData = {
    labels: attendanceData.map(a => a.date),
    datasets: [
      {
        label: 'Attendance Percentage (%)',
        data: attendanceData.map(a => (a.attendedPeriod / a.totalPeriod) * 100),
        backgroundColor: attendanceData.map(a => 
          (a.attendedPeriod / a.totalPeriod) * 100 > 75 ? 'rgba(75, 192, 192, 0.8)' : 'rgba(255, 99, 132, 0.8)'
        ),
        borderColor: attendanceData.map(a => 
          (a.attendedPeriod / a.totalPeriod) * 100 > 75 ? 'rgba(75, 192, 192, 1)' : 'rgba(255, 99, 132, 1)'
        ),
        borderWidth: 1,
      },
    ],
  };

  const barChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        callbacks: {
          label: (context) => `${context.raw.toFixed(2)}%`
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: 'Percentage (%)'
        }
      },
      x: {
        title: {
          display: true,
          text: 'Date'
        }
      }
    }
  };

  const renderCircularChart = (percentage, text) => {
    const pathColor = percentage >= 75 ? '#4a90e2' : '#ff6384';
    return (
      <div style={{ width: '100px', margin: '10px' }}>
        <CircularProgressbar
          value={percentage}
          text={`${percentage.toFixed(1)}%`}
          styles={buildStyles({
            pathColor: pathColor,
            textColor: '#333',
            trailColor: '#ddd',
            backgroundColor: '#f8f8f8'
          })}
        />
        <p style={{ textAlign: 'center', marginTop: '5px', fontSize: '14px', color: '#333' }}>{text}</p>
      </div>
    );
  };

  if (!studentData) {
    return <p>Loading student details...</p>;
  }

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Student Details</h2>
      
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '20px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' }}>
        <tbody>
          <tr>
            <td style={{ padding: '10px', backgroundColor: '#f8f8f8', fontWeight: 'bold', width: '25%' }}>Name</td>
            <td style={{ padding: '10px', width: '25%' }}>{studentData.name}</td>
            <td style={{ padding: '10px', backgroundColor: '#f8f8f8', fontWeight: 'bold', width: '25%' }}>Email</td>
            <td style={{ padding: '10px', width: '25%' }}>{studentData.email}</td>
          </tr>
          <tr>
            <td style={{ padding: '10px', backgroundColor: '#f8f8f8', fontWeight: 'bold' }}>Roll No</td>
            <td style={{ padding: '10px' }}>{studentData.rollno}</td>
            <td style={{ padding: '10px', backgroundColor: '#f8f8f8', fontWeight: 'bold' }}>Phone</td>
            <td style={{ padding: '10px' }}>{studentData.phone}</td>
          </tr>
          <tr>
            <td style={{ padding: '10px', backgroundColor: '#f8f8f8', fontWeight: 'bold' }}>Department</td>
            <td style={{ padding: '10px' }}>{studentData.department}</td>
            <td style={{ padding: '10px', backgroundColor: '#f8f8f8', fontWeight: 'bold' }}>Class</td>
            <td style={{ padding: '10px' }}>{studentData.className}</td>
          </tr>
          <tr>
            <td style={{ padding: '10px', backgroundColor: '#f8f8f8', fontWeight: 'bold' }}>Section</td>
            <td style={{ padding: '10px' }}>{studentData.section}</td>
            <td style={{ padding: '10px', backgroundColor: '#f8f8f8', fontWeight: 'bold' }}>Year</td>
            <td style={{ padding: '10px' }}>{studentData.year}</td>
          </tr>
        </tbody>
      </table>

      <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Marks</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '20px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' }}>
        <thead>
          <tr style={{ backgroundColor: '#f0f0f0' }}>
            <th style={{ padding: '10px', textAlign: 'left' }}>Subject Name</th>
            <th style={{ padding: '10px', textAlign: 'left' }}>Marks</th>
          </tr>
        </thead>
        <tbody>
          {studentData.subjects.map((subject, index) => (
            <tr key={index} style={{ textAlign: 'center' }}>
              <td style={{ padding: '10px' }}>{subject.subjectName}</td>
              <td style={{ padding: '10px' }}>{subject.marks}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Attendance</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '20px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' }}>
        <thead>
          <tr style={{ backgroundColor: '#f0f0f0' }}>
            <th style={{ padding: '10px', textAlign: 'left' }}>Date</th>
            <th style={{ padding: '10px', textAlign: 'left' }}>Day</th>
            <th style={{ padding: '10px', textAlign: 'left' }}>Total Periods</th>
            <th style={{ padding: '10px', textAlign: 'left' }}>Attended Periods</th>
          </tr>
        </thead>
        <tbody>
          {attendanceData.map((attendance, index) => (
            <tr key={index} style={{ textAlign: 'center' }}>
              <td style={{ padding: '10px' }}>{attendance.date}</td>
              <td style={{ padding: '10px' }}>{attendance.day}</td>
              <td style={{ padding: '10px' }}>{attendance.totalPeriod}</td>
              <td style={{ padding: '10px' }}>{attendance.attendedPeriod}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div style={{ display: 'flex', justifyContent: 'center', gap: '20px', marginTop: '20px' }}>
        {renderCircularChart(marksData.studentAverage, 'Student Average')}
        {renderCircularChart(marksData.departmentAverage, 'Department Average')}
        {renderCircularChart(marksData.collegeAverage, 'College Average')}
      </div>

      <div style={{ marginTop: '20px' }}>
        <Bar data={barChartData} options={barChartOptions} />
      </div>
    </div>
  );
};

export default ParticularStudent;
