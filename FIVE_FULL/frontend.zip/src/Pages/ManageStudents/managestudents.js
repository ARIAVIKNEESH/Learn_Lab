import React, { useState } from "react";
import axios from "axios";
import "./managestudents.css";

const ManageStudents = () => {
  const teacherId = localStorage.getItem("teacherId"); // Retrieve teacherId from local storage

  const [studentDetails, setStudentDetails] = useState({
    name: "",
    email: "",
    rollno: "",
    phone: "",
    address: "",
    department: "", // Will store selected department
    className: "",
    section: "",
    year: "",
    subjects: [],
    attendance: []
  });

  const departments = [
    "IT", "CSE", "AIDS", "AIML", "CIVIL", "MECHANICAL", 
    "ECE", "EEE", "EIE", "MECHATRONICS", "CSD", "CHEMICAL", "FT"
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setStudentDetails((prevDetails) => ({
      ...prevDetails,
      [name]: value
    }));
  };

  const handleAddSubject = () => {
    setStudentDetails((prevDetails) => ({
      ...prevDetails,
      subjects: [...prevDetails.subjects, { subjectName: "", marks: "" }]
    }));
  };

  const handleSubjectChange = (index, field, value) => {
    const updatedSubjects = [...studentDetails.subjects];
    updatedSubjects[index][field] = value;
    setStudentDetails({ ...studentDetails, subjects: updatedSubjects });
  };

  const handleAddAttendance = () => {
    setStudentDetails((prevDetails) => ({
      ...prevDetails,
      attendance: [...prevDetails.attendance, { date: "", day: "", totalPeriod: "", attendedPeriod: "" }]
    }));
  };

  const handleAttendanceChange = (index, field, value) => {
    const updatedAttendance = [...studentDetails.attendance];
    updatedAttendance[index] = { ...updatedAttendance[index], [field]: value };
    setStudentDetails({ ...studentDetails, attendance: updatedAttendance });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/api/managestudents", {
        teacherId,
        ...studentDetails
      });
      alert("Student added successfully!");
    } catch (error) {
      console.error("Error adding student", error);
    }
  };

  return (
    <div className="manage-students">
      <h2 className="title">Manage Students</h2>
      <form className="students-form" onSubmit={handleSubmit}>
        <div className="input-group">
          <label>Name</label>
          <input type="text" name="name" value={studentDetails.name} onChange={handleChange} required />
        </div>
        <div className="input-group">
          <label>Email</label>
          <input type="email" name="email" value={studentDetails.email} onChange={handleChange} required />
        </div>
        <div className="input-group">
          <label>Roll No</label>
          <input type="text" name="rollno" value={studentDetails.rollno} onChange={handleChange} required />
        </div>
        <div className="input-group">
          <label>Phone</label>
          <input type="text" name="phone" value={studentDetails.phone} onChange={handleChange} />
        </div>
        <div className="input-group">
          <label>Address</label>
          <input type="text" name="address" value={studentDetails.address} onChange={handleChange} />
        </div>

        <div className="input-group">
          <label>Department</label>
          <select name="department" value={studentDetails.department} onChange={handleChange} required>
            <option value="">Select Department</option>
            {departments.map((department, index) => (
              <option key={index} value={department}>{department}</option>
            ))}
          </select>
        </div>

        <div className="input-group">
          <label>Class</label>
          <input type="text" name="className" value={studentDetails.className} onChange={handleChange} />
        </div>
        <div className="input-group">
          <label>Section</label>
          <input type="text" name="section" value={studentDetails.section} onChange={handleChange} />
        </div>
        <div className="input-group">
          <label>Year</label>
          <input type="text" name="year" value={studentDetails.year} onChange={handleChange} />
        </div>

        <div className="subjects-section">
          <label>Subjects</label>
          {studentDetails.subjects.map((subject, index) => (
            <div key={index} className="subject-inputs">
              <input
                type="text"
                value={subject.subjectName}
                onChange={(e) => handleSubjectChange(index, "subjectName", e.target.value)}
                placeholder={`Subject ${index + 1}`}
              />
              <input
                type="number"
                value={subject.marks}
                onChange={(e) => handleSubjectChange(index, "marks", e.target.value)}
                placeholder="Marks"
              />
            </div>
          ))}
          <button type="button" className="add-btn" onClick={handleAddSubject}>Add Subject</button>
        </div>

        <div className="attendance-section">
          <label>Attendance</label>
          {studentDetails.attendance.map((attendance, index) => (
            <div key={index} className="attendance-inputs">
              <input
                type="date"
                value={attendance.date}
                onChange={(e) => handleAttendanceChange(index, "date", e.target.value)}
                required
              />
              <input
                type="text"
                value={attendance.day}
                onChange={(e) => handleAttendanceChange(index, "day", e.target.value)}
                placeholder="Day"
                required
              />
              <input
                type="number"
                value={attendance.totalPeriod}
                onChange={(e) => handleAttendanceChange(index, "totalPeriod", e.target.value)}
                placeholder="Total Period"
                required
              />
              <input
                type="number"
                value={attendance.attendedPeriod}
                onChange={(e) => handleAttendanceChange(index, "attendedPeriod", e.target.value)}
                placeholder="Attended Period"
                required
              />
            </div>
          ))}
          <button type="button" className="add-btn" onClick={handleAddAttendance}>Add Attendance</button>
        </div>

        <button type="submit" className="submit-btn">Add Student</button>
      </form>
    </div>
  );
};

export default ManageStudents;
