import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './login.css';
import 'bootstrap/dist/css/bootstrap.min.css';

const Login = ({ setLoggedIn }) => {
  const [formData, setFormData] = useState({
    identifier: '',
    password: '',
  });
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('http://localhost:5000/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        localStorage.setItem('teacherId', data.teacherId);
        localStorage.setItem('email', data.email);
        localStorage.setItem('name', data.name);

        setLoggedIn(true);
        navigate('/home');
      } else {
        setErrorMessage(data.message || 'Login failed');
      }
    } catch (error) {
      console.error('Error:', error);
      setErrorMessage('An error occurred during login');
    }
  };

  return (
    <div className="container d-flex justify-content-center align-items-center vh-100">
      <div className="col-12 col-sm-8 col-md-6 col-lg-4">
        <div className="card p-4 shadow-lg">
          <h2 className="text-center mb-4">Login</h2>
          
          {errorMessage && <p className="text-danger text-center">{errorMessage}</p>}
          
          <form onSubmit={handleLogin}>
            <div className="mb-3">
              <input
                type="text"
                name="identifier"
                className="form-control"
                placeholder="Teacher ID or Email"
                value={formData.identifier}
                onChange={handleChange}
                required
              />
            </div>
            <div className="mb-3">
              <input
                type="password"
                name="password"
                className="form-control"
                placeholder="Password"
                value={formData.password}
                onChange={handleChange}
                required
              />
            </div>
            <button className="btn btn-primary w-100" type="submit">
              Login
            </button>
            <div className="text-center mt-3">
              <p>Don't have an account? <a href="/signup">Sign Up</a></p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
